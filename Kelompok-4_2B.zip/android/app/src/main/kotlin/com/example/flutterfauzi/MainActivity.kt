package com.example.flutterfauzi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
