import 'package:flutter/material.dart';

void main() => runApp(Form());

class Form extends StatelessWidget {
  Form({Key? key});
  String textTitle = 'Form Pendaftaran Mahasiswa';
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: textTitle,
      home: Scaffold(
        appBar: AppBar(title: Text(textTitle)),
        body: Center(
          child: MyStatefulWidget(),
        ),
      ),
    );
  }
}

enum SingingCharacter { lafayette, jefferson }

class MyStatefulWidget extends StatefulWidget {
  MyStatefulWidget({Key? key});

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  DateTime selectedDate = DateTime.now();
  SingingCharacter? _character = SingingCharacter.lafayette;
  final _minimumPadding = 7.5;
  final _formKey = GlobalKey<FormState>();

  Future<Null> _selectedDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: selectedDate.subtract(Duration(days: 30)),
        lastDate: DateTime(selectedDate.year + 1));
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  @override
  TextEditingController namalengkapController = TextEditingController();
  TextEditingController alamatController = TextEditingController();
  TextEditingController asalsekolahController = TextEditingController();
  TextEditingController tempatlahirController = TextEditingController();
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        key: _formKey,
        child: Container(
          padding: EdgeInsets.all(_minimumPadding * 3),
          child: Column(
            children: [
              Padding(
                  padding: EdgeInsets.only(
                      top: _minimumPadding, bottom: _minimumPadding),
                  child: TextFormField(
                    keyboardType: TextInputType.text,
                    controller: namalengkapController,
                    decoration: InputDecoration(
                        labelText: 'Nama Lengkap',
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide(),
                        )),
                  )),
              Padding(
                  padding: EdgeInsets.only(
                      top: _minimumPadding, bottom: _minimumPadding),
                  child: TextFormField(
                    keyboardType: TextInputType.text,
                    controller: alamatController,
                    decoration: InputDecoration(
                        labelText: 'Alamat ',
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide(),
                        )),
                  )),
              Padding(
                  padding: EdgeInsets.only(
                      top: _minimumPadding, bottom: _minimumPadding),
                  child: TextFormField(
                    keyboardType: TextInputType.text,
                    controller: asalsekolahController,
                    decoration: InputDecoration(
                        labelText: 'Asal Sekolah',
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide(),
                        )),
                  )),
              Padding(
                  padding: EdgeInsets.only(
                      top: _minimumPadding, bottom: _minimumPadding),
                  child: TextFormField(
                    keyboardType: TextInputType.text,
                    controller: tempatlahirController,
                    decoration: InputDecoration(
                        labelText: 'Tempat Lahir',
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide(),
                        )),
                  )),
              Text(
                "Tanggal Lahir",
                style: TextStyle(
                  letterSpacing: 1.1,
                  wordSpacing: 2,
                  height: 3,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Text(
                    "${selectedDate.toLocal()}".split(' ')[0],
                    style: TextStyle(
                      fontSize: 15,
                      foreground: Paint()
                        ..style = PaintingStyle.stroke
                        ..strokeWidth = 1
                        ..color = Colors.black,
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5)),
                    color: Colors.black,
                    textColor: Colors.white,
                    onPressed: () => _selectedDate(context),
                    child: Text('Selected Date'),
                  ),
                ],
              ),
              Text(
                "Jenis Kelamin",
                style: TextStyle(
                  letterSpacing: 1.1,
                  wordSpacing: 1,
                  height: 3,
                ),
              ),
              ListTile(
                title: Text('Perempuan'),
                leading: Radio<SingingCharacter>(
                  value: SingingCharacter.lafayette,
                  groupValue: _character,
                  onChanged: (SingingCharacter? value) {
                    setState(() {
                      _character = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: Text('Laki-laki'),
                leading: Radio<SingingCharacter>(
                  value: SingingCharacter.jefferson,
                  groupValue: _character,
                  onChanged: (SingingCharacter? value) {
                    setState(() {
                      _character = value;
                    });
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                    top: _minimumPadding, bottom: _minimumPadding),
                child: Row(
                  children: [
                    Expanded(
                      child: RaisedButton(
                          color: Colors.black,
                          textColor: Colors.white,
                          child: Text(
                            "Simpan",
                            textScaleFactor: 1.3,
                          ),
                          onPressed: () {}),
                    ),
                    Expanded(
                        child: RaisedButton(
                            color: Colors.black,
                            textColor: Colors.white,
                            child: Text(
                              "Cancel",
                              textScaleFactor: 1.3,
                            ),
                            onPressed: () {
                              setState(() {
                                _reset();
                              });
                            })),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _reset() {
    namalengkapController.text = '';
    alamatController.text = '';
    asalsekolahController.text = '';
    tempatlahirController.text = '';
  }
}
