import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutterfauzi/formdetail.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:dropdown_button2/dropdown_button2.dart';

//enum JenisKelamin { Laki, Perempuan, Default }

class FormPage extends StatefulWidget {
  const FormPage({Key? key}) : super(key: key);
  @override
  State<FormPage> createState() => _form();
}

class _form extends State<FormPage> {
  XFile? image;
  // JenisKelamin? _character = JenisKelamin.Laki;
  var formKey = GlobalKey<FormState>();
  TextEditingController name = TextEditingController();
  TextEditingController tempatTinggal = TextEditingController();
  TextEditingController tempatLahir = TextEditingController();
  TextEditingController tanggalLahir = TextEditingController();
  TextEditingController dateController = TextEditingController();
  TextEditingController kelamin = TextEditingController();
  TextEditingController _pengalamankerja = TextEditingController();
  TextEditingController ktp = TextEditingController();
  TextEditingController npwp = TextEditingController();
  ImagePicker picker = ImagePicker();
  TextEditingController social = TextEditingController();
  TextEditingController ket = TextEditingController();

  final List<String> genderItems = [
    'Laki - Laki',
    'Perempuan',
  ];

  String? selectedValue;

  final List<String> items = [
    '1 Tahun',
    '2 Tahun',
    '3 Tahun',
    '4 Tahum',
    '5 Tahun',
  ];
  String? selectedValue2;

  List<DropdownMenuItem<String>> _addDividersAfterItems(List<String> items) {
    List<DropdownMenuItem<String>> _menuItems = [];
    for (var item in items) {
      _menuItems.addAll(
        [
          DropdownMenuItem<String>(
            value: item,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text(
                item,
                style: const TextStyle(
                  fontSize: 14,
                ),
              ),
            ),
          ),
          //If it's last item, we will not add Divider after it.
          if (item != items.last)
            const DropdownMenuItem<String>(
              enabled: false,
              child: Divider(),
            ),
        ],
      );
    }
    return _menuItems;
  }

  List<double> _getCustomItemsHeights() {
    List<double> _itemsHeights = [];
    for (var i = 0; i < (items.length * 2) - 1; i++) {
      if (i.isEven) {
        _itemsHeights.add(40);
      }
      //Dividers indexes will be the odd indexes
      if (i.isOdd) {
        _itemsHeights.add(4);
      }
    }
    return _itemsHeights;
  }

  Future getImage(ImageSource media) async {
    var img = await picker.pickImage(source: media);

    setState(() {
      image = img;
    });
  }

  Future<String> getFilePath() async {
    Directory appDocumentsDirectory =
        await getApplicationDocumentsDirectory(); // 1
    Directory appSupportDirectory = await getApplicationSupportDirectory();
    Directory appTemporaryDirectory = await getTemporaryDirectory();
    String appDocumentsPath = appDocumentsDirectory.path; // 2
    String filePath = '$appDocumentsPath/lib/data_pegawai/data.txt'; // 3

    return filePath;
  }

  void saveFile() async {
    File file = File(await getFilePath()); // 1
    file.writeAsString(
        "This is my demo text that will be saved to : /lib/data_pegawai/data.txt"); // 2
  }

  void readFile() async {
    File file = File(await getFilePath()); // 1
    String fileContent = await file.readAsString(); // 2

    print('File Content: $fileContent');
  }

  void simpan() {
    AlertDialog alert = AlertDialog(
      title: Text("Konfirmasi"),
      content: Container(
        child: Text("Apakah data akan disimpan"),
      ),
      actions: [
        TextButton(
          child: Text('OK'),
          onPressed: () {
            String namaLengkap = name.text;
            String alamat = tempatTinggal.text;
            String tempatlahir = tempatLahir.text;
            String tanggalLahir = dateController.text;
            String jeniskelamin = kelamin.text;
            String pengalamankerja = _pengalamankerja.text;
            int noktp = int.parse(ktp.text);
            int nonpwp = int.parse(npwp.text);
            String linksocial = social.text;
            String keterangan = ket.text;
            Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => ProdukDetail(
                      namaLengkap: namaLengkap,
                      alamat: alamat,
                      tempatlahir: tempatlahir,
                      tanggalLahir: tanggalLahir,
                      jeniskelamin: jeniskelamin,
                      pengalamankerja: pengalamankerja,
                      ktp: noktp,
                      npwp: nonpwp,
                      picker: picker,
                      linksocial: linksocial,
                      keterangan: keterangan,
                    )));
          },
        ),
        TextButton(
            child: Text('CANCEL'),
            onPressed: () {
              name.clear();
              tempatTinggal.clear();
              tempatLahir.clear();
              tanggalLahir.clear();
              dateController.clear();
              kelamin.clear();
              ktp.clear();
              npwp.clear();
              //picker.clear();
              social.clear();
              ket.clear();
              Navigator.of(context).pop();
            }),
      ],
    );
    showDialog(context: context, builder: (context) => alert);
    return;
  }

  void cancel() {
    AlertDialog alert = AlertDialog(
      title: Text("Konfirmasi"),
      content: Container(
        child: Text("Bersihkan data?"),
      ),
      actions: [
        TextButton(
          child: Text('OK'),
          onPressed: () {
            name.clear();
            tempatTinggal.clear();
            tempatLahir.clear();
            tanggalLahir.clear();
            dateController.clear();
            kelamin.clear();
            ktp.clear();
            npwp.clear();
            //picker.clear();
            social.clear();
            ket.clear();
          },
        ),
        TextButton(
          child: Text('CANCEL'),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ],
    );
    showDialog(context: context, builder: (context) => alert);
    return;
  }

  void myAlert() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            title: Text('Please choose media to select'),
            content: Container(
              height: MediaQuery.of(context).size.height / 6,
              child: Column(
                children: [
                  ElevatedButton(
                    //if user click this button, user can upload image from gallery
                    onPressed: () {
                      Navigator.pop(context);
                      getImage(ImageSource.gallery);
                    },
                    child: Row(
                      children: [
                        Icon(Icons.image),
                        Text('From Gallery'),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    //if user click this button. user can upload image from camera
                    onPressed: () {
                      Navigator.pop(context);
                      getImage(ImageSource.camera);
                    },
                    child: Row(
                      children: [
                        Icon(Icons.camera),
                        Text('From Camera'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  void inistate() {
    super.initState();
    dateController.text = "";
  }

  @override
  Widget build(BuildContext context) {
    var pkItems;
    var selectedpkValue;
    return Scaffold(
      appBar: AppBar(
        brightness: Brightness.light,
        backgroundColor: Color(0xfff0ff16),
        title: Text(' Project UTS', style: TextStyle(color: Color(0xf9050505))),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(children: [
                Text(
                  'Form Registrasi Pegawai',
                  style: TextStyle(
                      color: Color(0xff252121),
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: name,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Nama Lengkap",
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(),
                      ),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: tempatTinggal,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Alamat",
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(),
                      ),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: tempatLahir,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Tempat Lahir",
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(),
                      ),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextField(
                  controller: dateController,
                  decoration: const InputDecoration(
                    labelText: "Tanggal Lahir",
                    icon: Icon(Icons.calendar_today),
                  ), //editing controller of this TextFiel
                  readOnly: true, // when true user cannot edit text
                  onTap: () async {
                    //when click we have to show the datepicker

                    DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(), //get today's date
                        firstDate: DateTime(
                            2000), //DateTime.now() - not to allow to choose before today.
                        lastDate: DateTime(2101));
                    if (pickedDate != null) {
                      setState(() {
                        dateController.text = pickedDate.toString();
                      });
                    } else {
                      print("Tidak Terpilih");
                    }
                  },
                ),
                SizedBox(
                  height: 16,
                ),
                Text(
                  'Jenis Kelamin',
                  style: TextStyle(fontSize: 17),
                ),
                SizedBox(
                  height: 10,
                ),
                DropdownButtonFormField2(
                  decoration: InputDecoration(
                    isDense: true,
                    contentPadding: EdgeInsets.zero,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  isExpanded: true,
                  hint: const Text(
                    'Pilih',
                    style: TextStyle(fontSize: 14),
                  ),
                  icon: const Icon(
                    Icons.arrow_drop_down,
                    color: Colors.black45,
                  ),
                  iconSize: 30,
                  buttonHeight: 60,
                  buttonPadding: const EdgeInsets.only(left: 20, right: 10),
                  dropdownDecoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  items: genderItems
                      .map((item) => DropdownMenuItem<String>(
                            value: item,
                            child: Text(
                              item,
                              style: const TextStyle(
                                fontSize: 14,
                              ),
                            ),
                          ))
                      .toList(),
                  validator: (value) {
                    if (value == null) {
                      return 'Pilih';
                    }
                  },
                  onChanged: (value) {},
                  onSaved: (value) {
                    selectedValue = value.toString();
                  },
                ),
                const SizedBox(height: 30),
                Text(
                  'Pengalaman Kerja',
                  style: TextStyle(fontSize: 17),
                ),
                SizedBox(
                  height: 10,
                ),
                DropdownButtonFormField2(
                  decoration: InputDecoration(
                    isDense: true,
                    contentPadding: EdgeInsets.zero,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  isExpanded: true,
                  hint: const Text(
                    'Pilih',
                    style: TextStyle(fontSize: 14),
                  ),
                  icon: const Icon(
                    Icons.arrow_drop_down,
                    color: Colors.black45,
                  ),
                  iconSize: 30,
                  buttonHeight: 60,
                  buttonPadding: const EdgeInsets.only(left: 20, right: 10),
                  dropdownDecoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  items: items
                      .map((item) => DropdownMenuItem<String>(
                            value: item,
                            child: Text(
                              item,
                              style: const TextStyle(
                                fontSize: 14,
                              ),
                            ),
                          ))
                      .toList(),
                  validator: (value) {
                    if (value == null) {
                      return 'Pilih';
                    }
                  },
                  onChanged: (value) {},
                  onSaved: (value) {
                    selectedValue2 = value.toString();
                  },
                ),
                const SizedBox(height: 30),
                TextFormField(
                    controller: ktp,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "NO KTP",
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(),
                      ),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: npwp,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "NO NPWP",
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(),
                      ),
                    )),
                SizedBox(
                  height: 34,
                ),
                ElevatedButton(
                  onPressed: () {
                    myAlert();
                  },
                  child: Text('Upload Photo'),
                ),
                SizedBox(
                  height: 10,
                ),
                image != null
                    ? Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.file(
                            //to show image, you type like this.
                            File(image!.path),
                            fit: BoxFit.cover,
                            width: MediaQuery.of(context).size.width,
                            height: 300,
                          ),
                        ),
                      )
                    : Text(
                        "No Image",
                        style: TextStyle(fontSize: 20),
                      ),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: social,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Link Social Media",
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(),
                      ),
                      // border: OutlineInputBorder(
                      // borderRadius: BorderRadius.circular(20.0)),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: ket,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Keterangan",
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(),
                      ),
                      // border: OutlineInputBorder(
                      // borderRadius: BorderRadius.circular(20.0)),
                    )),
                SizedBox(
                  height: 16,
                ),
                new Padding(padding: new EdgeInsets.only(top: 20.0)),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                          onPressed: () {
                            simpan();
                          },
                          child: const Text("Simpan")),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                        child: ElevatedButton(
                            onPressed: () {
                              cancel();
                            },
                            child: Text("Cancel"))),
                  ],
                ),
              ]),
            )),
      ),
    );
  }
}
