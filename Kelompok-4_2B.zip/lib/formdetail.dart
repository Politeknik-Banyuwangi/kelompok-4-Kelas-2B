import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ProdukDetail extends StatefulWidget {
  final String? namaLengkap;
  final String? alamat;
  final String? tempatlahir;
  final String? tanggalLahir;
  final String? jeniskelamin;
  final String? pengalamankerja;
  final int? ktp;
  final int? npwp;
  final ImagePicker? picker;
  final String? linksocial;
  final String? keterangan;

  const ProdukDetail(
      {Key? key,
      this.namaLengkap,
      this.alamat,
      this.tempatlahir,
      this.tanggalLahir,
      this.jeniskelamin,
      this.pengalamankerja,
      this.ktp,
      this.npwp,
      this.picker,
      this.linksocial,
      this.keterangan})
      : super(key: key);

  @override
  _ProdukDetailState createState() => _ProdukDetailState();
}

class _ProdukDetailState extends State<ProdukDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        brightness: Brightness.light,
        backgroundColor: Color(0xfff0ff16),
        title: Text('Tugas Projeck UTS',
            style: TextStyle(color: Color(0xf9050505))),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Text(
            'Data Registrasi Pegawai',
            style: TextStyle(
                color: Color(0xff252121),
                fontSize: 18,
                fontWeight: FontWeight.bold),
          ),
          Text("Nama Lengkap: " + widget.namaLengkap.toString()),
          Text("Alamat : " + widget.alamat.toString()),
          Text("Tempat Lahir : " + widget.tempatlahir.toString()),
          Text("Tanggal Lahir : " + widget.tanggalLahir.toString()),
          Text("Jenis Kelamin : " + widget.jeniskelamin.toString()),
          Text("Pengalaman Kerja : " + widget.pengalamankerja.toString()),
          Text("NO KTP : ${widget.ktp}"),
          Text("NO NPWP : ${widget.npwp}"),
          Text("Upload Photo : ${widget.picker}"),
          Text("Link SocialMedia : " + widget.linksocial.toString()),
          Text("Keterangan : " + widget.keterangan.toString()),
        ],
      ),
    );
  }
}
